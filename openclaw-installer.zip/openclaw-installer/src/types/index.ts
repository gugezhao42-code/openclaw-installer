export interface InstallOptions {
  mode: 'interactive' | 'silent' | 'quick' | 'repair';
  config?: string;
  model?: ModelProvider;
  apiKey?: string;
  port?: number;
  skipNodeCheck?: boolean;
  registry?: string;
  verbose?: boolean;
}

export interface InstallResult {
  success: boolean;
  version?: string;
  gatewayUrl?: string;
  dashboardUrl?: string;
  configPath?: string;
  logPath?: string;
  errors: InstallError[];
  warnings: InstallWarning[];
}

export interface InstallError {
  code: string;
  message: string;
  stage: InstallStage;
  recoverable: boolean;
  suggestion?: string;
}

export interface InstallWarning {
  code: string;
  message: string;
  impact: 'low' | 'medium' | 'high';
}

export interface InstallProgress {
  stage: InstallStage;
  progress: number;
  message: string;
  details?: Record<string, unknown>;
}

export type InstallStage =
  | 'idle'
  | 'detecting'
  | 'installing-nodejs'
  | 'installing-openclaw'
  | 'configuring'
  | 'configuring-model'
  | 'starting-gateway'
  | 'health-check'
  | 'completed'
  | 'failed';

export interface ModelProvider {
  name: 'kimi' | 'openai' | 'anthropic' | 'ollama' | 'custom';
  model: string;
  apiKey?: string;
  baseUrl?: string;
}

export interface EnvironmentInfo {
  nodejs: NodeJSInfo | null;
  npm: NpmInfo | null;
  permissions: PermissionInfo;
  ports: PortInfo[];
  platform: PlatformInfo;
  openclaw: OpenClawInfo | null;
}

export interface NodeJSInfo {
  version: string;
  path: string;
  satisfies: (range: string) => boolean;
}

export interface NpmInfo {
  version: string;
  path: string;
  registry: string;
}

export interface PermissionInfo {
  admin: boolean;
  canWriteGlobal: boolean;
  canWriteHome: boolean;
}

export interface PortInfo {
  port: number;
  available: boolean;
  process?: string;
}

export interface PlatformInfo {
  os: 'windows' | 'macos' | 'linux';
  arch: 'x64' | 'arm64' | 'ia32';
  version: string;
}

export interface OpenClawInfo {
  installed: boolean;
  version?: string;
  path?: string;
}

export type ProgressCallback = (progress: InstallProgress) => void;
