import { readFile, writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
import { logger } from '../../utils/logger.js';
import { getOpenClawDir } from '../../utils/platform.js';
import type { ModelProvider } from '../../types/index.js';

export interface ConfigTemplate {
  meta: {
    lastTouchedVersion: string;
    lastTouchedAt: string;
  };
  agents: {
    defaults: {
      workspace: string;
      model?: string;
    };
  };
  gateway: {
    mode: 'local' | 'remote';
    port: number;
    auth: {
      token: string;
    };
  };
}

export class ConfigGenerator {
  private openclawDir: string;

  constructor() {
    this.openclawDir = getOpenClawDir();
  }

  async generate(options: {
    port?: number;
    model?: ModelProvider;
    workspace?: string;
  }): Promise<string> {
    const config: ConfigTemplate = {
      meta: {
        lastTouchedVersion: '2026.2.26',
        lastTouchedAt: new Date().toISOString(),
      },
      agents: {
        defaults: {
          workspace: options.workspace || join(this.openclawDir, 'workspace'),
        },
      },
      gateway: {
        mode: 'local',
        port: options.port || 19001,
        auth: {
          token: 'auto',
        },
      },
    };

    if (options.model) {
      config.agents.defaults.model = this.getDefaultModel(options.model);
    }

    const configPath = join(this.openclawDir, 'openclaw.json');
    await writeFile(configPath, JSON.stringify(config, null, 2));

    logger.info(`Config generated at: ${configPath}`);
    return configPath;
  }

  async generateAuthProfiles(
    provider: ModelProvider,
    apiKey: string
  ): Promise<string> {
    const authPath = join(this.openclawDir, 'agents', 'main', 'agent', 'auth-profiles.json');

    let existingConfig: any = { profiles: {}, order: [] };

    if (existsSync(authPath)) {
      try {
        const content = await readFile(authPath, 'utf-8');
        existingConfig = JSON.parse(content);
      } catch {
        // Use default config
      }
    }

    const profileId = `${provider.name}:default`;

    existingConfig.profiles[profileId] = {
      id: profileId,
      provider: provider.name,
      apiKey: apiKey,
      baseUrl: provider.baseUrl,
      createdAt: new Date().toISOString(),
    };

    if (!existingConfig.order.includes(profileId)) {
      existingConfig.order.unshift(profileId);
    }

    // Ensure directory exists
    const agentDir = join(this.openclawDir, 'agents', 'main', 'agent');
    if (!existsSync(agentDir)) {
      await mkdir(agentDir, { recursive: true });
    }

    await writeFile(authPath, JSON.stringify(existingConfig, null, 2));

    logger.info(`Auth profiles generated at: ${authPath}`);
    return authPath;
  }

  private getDefaultModel(provider: ModelProvider): string {
    const modelMap: Record<string, string> = {
      kimi: 'moonshot/kimi-k2.5',
      openai: 'openai/gpt-4o',
      anthropic: 'anthropic/claude-opus-4-6',
      ollama: 'ollama/llama3',
      custom: provider.model,
    };

    return modelMap[provider.name] || provider.model;
  }

  async readConfig(): Promise<ConfigTemplate | null> {
    const configPath = join(this.openclawDir, 'openclaw.json');

    if (!existsSync(configPath)) {
      return null;
    }

    try {
      const content = await readFile(configPath, 'utf-8');
      return JSON.parse(content);
    } catch {
      return null;
    }
  }

  async updateConfig(updates: Partial<ConfigTemplate>): Promise<void> {
    const config = await this.readConfig();

    if (!config) {
      throw new Error('Config file not found');
    }

    const updated = { ...config, ...updates };
    const configPath = join(this.openclawDir, 'openclaw.json');

    await writeFile(configPath, JSON.stringify(updated, null, 2));
  }
}

export const configGenerator = new ConfigGenerator();
