import winston from 'winston';
import { homedir } from 'os';
import { join } from 'path';
import { existsSync, mkdirSync } from 'fs';

const LOG_DIR = join(homedir(), '.openclaw-installer', 'logs');

if (!existsSync(LOG_DIR)) {
  mkdirSync(LOG_DIR, { recursive: true });
}

const customFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ level, message, timestamp, stack }) => {
    const prefix = stack ? `\n${stack}` : '';
    return `[${timestamp}] ${level.toUpperCase()}: ${message}${prefix}`;
  })
);

export const logger = winston.createLogger({
  level: 'info',
  format: customFormat,
  transports: [
    new winston.transports.File({
      filename: join(LOG_DIR, 'install.log'),
      maxsize: 5242880,
      maxFiles: 3,
    }),
    new winston.transports.File({
      filename: join(LOG_DIR, 'error.log'),
      level: 'error',
      maxsize: 5242880,
      maxFiles: 3,
    }),
  ],
});

export function setVerboseLogging(verbose: boolean): void {
  if (verbose) {
    logger.add(
      new winston.transports.Console({
        format: winston.format.combine(
          winston.format.colorize(),
          winston.format.printf(({ level, message }) => `${level}: ${message}`)
        ),
      })
    );
    logger.level = 'debug';
  }
}

export function getLogPath(): string {
  return join(LOG_DIR, 'install.log');
}
