import { platform, arch, release } from 'os';
import type { PlatformInfo } from '../types';

export function getPlatform(): PlatformInfo {
  const osMap: Record<string, PlatformInfo['os']> = {
    win32: 'windows',
    darwin: 'macos',
    linux: 'linux',
  };

  const archMap: Record<string, PlatformInfo['arch']> = {
    x64: 'x64',
    arm64: 'arm64',
    ia32: 'ia32',
    x86: 'ia32',
  };

  return {
    os: osMap[platform()] || 'linux',
    arch: archMap[arch()] || 'x64',
    version: release(),
  };
}

export function isWindows(): boolean {
  return platform() === 'win32';
}

export function isMacOS(): boolean {
  return platform() === 'darwin';
}

export function isLinux(): boolean {
  return platform() === 'linux';
}

export function getShell(): string {
  if (isWindows()) {
    return process.env.COMSPEC || 'cmd.exe';
  }
  return process.env.SHELL || '/bin/bash';
}

export function getHomeDir(): string {
  return process.env.USERPROFILE || process.env.HOME || '';
}

export function getOpenClawDir(): string {
  return `${getHomeDir()}/.openclaw`;
}
