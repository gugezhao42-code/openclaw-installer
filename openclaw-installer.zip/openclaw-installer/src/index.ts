#!/usr/bin/env node

import { Command } from 'commander';
import pc from 'picocolors';
import {
  intro,
  outro,
  text,
  select,
  password,
  confirm,
  spinner,
  isCancel,
  cancel,
} from '@clack/prompts';
import { OpenClawInstaller } from './core/installer.js';
import { detector } from './core/detector.js';
import { setVerboseLogging, getLogPath } from './utils/logger.js';
import type { InstallOptions, InstallProgress, ModelProvider } from './types/index.js';

const VERSION = '1.0.0';

const program = new Command();

program
  .name('openclaw-install')
  .description('One-click installer for OpenClaw')
  .version(VERSION)
  .option('-s, --silent', 'Silent mode (non-interactive)', false)
  .option('-q, --quick', 'Quick install with defaults', false)
  .option('-r, --repair', 'Repair existing installation', false)
  .option('-c, --config <path>', 'Path to config file')
  .option('--model <provider>', 'AI model provider (kimi|openai|anthropic|ollama)')
  .option('--api-key <key>', 'API key for the model provider')
  .option('--port <port>', 'Gateway port', parseInt)
  .option('--registry <url>', 'npm registry URL')
  .option('-v, --verbose', 'Verbose output', false)
  .action(async (options) => {
    await main(options);
  });

program
  .command('uninstall')
  .description('Uninstall OpenClaw')
  .option('-y, --yes', 'Skip confirmation', false)
  .action(async (options) => {
    await uninstall(options);
  });

program
  .command('status')
  .description('Check installation status')
  .action(async () => {
    await checkStatus();
  });

async function main(options: any): Promise<void> {
  setVerboseLogging(options.verbose);

  console.log('');
  console.log(pc.cyan('🦞 OpenClaw Installer v' + VERSION));
  console.log(pc.dim('━'.repeat(50)));
  console.log('');

  // Determine install mode
  let mode: InstallOptions['mode'] = 'interactive';
  if (options.silent) mode = 'silent';
  else if (options.quick) mode = 'quick';
  else if (options.repair) mode = 'repair';

  // Interactive mode
  if (mode === 'interactive') {
    intro(pc.bgCyan(pc.black(' OpenClaw 安装向导 ')));

    // Detect environment first
    const s = spinner();
    s.start('检测系统环境...');

    const env = await detector.detect();

    s.stop('环境检测完成');

    // Show environment info
    console.log('');
    console.log(pc.dim('  系统信息:'));
    console.log(pc.dim(`  ├─ 操作系统: ${env.platform.os} ${env.platform.arch}`));
    console.log(pc.dim(`  ├─ Node.js: ${env.nodejs?.version || '未安装'}`));
    console.log(pc.dim(`  └─ npm: ${env.npm?.version || '未安装'}`));
    console.log('');

    // Check for issues
    if (!env.nodejs || !env.nodejs.satisfies('>=22.0.0')) {
      const proceed = await confirm({
        message: 'Node.js 版本不满足要求 (需要 22+)，是否继续？',
        initialValue: false,
      });

      if (isCancel(proceed) || !proceed) {
        cancel('安装已取消');
        return;
      }
    }

    // Ask for model provider
    const modelChoice = await select({
      message: '选择 AI 模型提供商',
      options: [
        { value: 'kimi', label: 'Kimi (月之暗面)', hint: '推荐国内用户' },
        { value: 'openai', label: 'OpenAI (GPT-4)', hint: '需要 API Key' },
        { value: 'anthropic', label: 'Anthropic (Claude)', hint: '需要 API Key' },
        { value: 'ollama', label: 'Ollama (本地)', hint: '需要本地运行 Ollama' },
        { value: 'skip', label: '跳过，稍后配置', hint: '可在 Dashboard 配置' },
      ],
      initialValue: 'kimi',
    });

    if (isCancel(modelChoice)) {
      cancel('安装已取消');
      return;
    }

    let modelProvider: ModelProvider | undefined;
    let apiKey: string | undefined;

    if (modelChoice !== 'skip') {
      // Ask for API key
      const keyInput = await password({
        message: `输入 ${(modelChoice as string).toUpperCase()} API Key`,
        validate: (value) => {
          if (!value || value.length < 10) {
            return '请输入有效的 API Key';
          }
        },
      });

      if (isCancel(keyInput)) {
        cancel('安装已取消');
        return;
      }

      apiKey = keyInput;
      modelProvider = {
        name: modelChoice as ModelProvider['name'],
        model: '',
      };
    }

    // Ask for port
    const availablePort = env.ports.find((p) => p.available)?.port || 19001;
    const portInput = await text({
      message: 'Gateway 端口',
      initialValue: String(availablePort),
      validate: (value) => {
        const port = parseInt(value);
        if (isNaN(port) || port < 1024 || port > 65535) {
          return '请输入有效的端口号 (1024-65535)';
        }
      },
    });

    if (isCancel(portInput)) {
      cancel('安装已取消');
      return;
    }

    options.port = parseInt(portInput);
    options.model = modelProvider?.name;
    options.apiKey = apiKey;
  }

  // Quick mode defaults
  if (mode === 'quick') {
    if (!options.model) options.model = 'kimi';
    if (!options.port) options.port = 19001;
  }

  // Create installer
  const installer = new OpenClawInstaller({
    mode,
    config: options.config,
    model: options.model ? { name: options.model, model: '' } : undefined,
    apiKey: options.apiKey,
    port: options.port,
    registry: options.registry,
    verbose: options.verbose,
  });

  // Progress tracking
  const progressSpinner = spinner();
  let currentStage = '';

  installer.onProgress((progress: InstallProgress) => {
    const stageMessages: Record<string, string> = {
      idle: '准备中...',
      detecting: '检测系统环境...',
      'installing-nodejs': '安装 Node.js...',
      'installing-openclaw': '安装 OpenClaw...',
      configuring: '初始化配置...',
      'configuring-model': '配置 AI 模型...',
      'starting-gateway': '启动 Gateway...',
      'health-check': '健康检查...',
      completed: '安装完成！',
      failed: '安装失败',
    };

    const message = stageMessages[progress.stage] || progress.message;

    if (progress.stage !== currentStage) {
      if (currentStage) {
        progressSpinner.stop(message);
      }
      currentStage = progress.stage;
      progressSpinner.start(message);
    }
  });

  // Run installation
  const result = await installer.install();

  progressSpinner.stop();

  console.log('');

  if (result.success) {
    outro(pc.green('✓ 安装成功！'));

    console.log('');
    console.log(pc.cyan('  安装信息:'));
    console.log(pc.dim(`  ├─ 版本: ${result.version}`));
    console.log(pc.dim(`  ├─ Gateway: ${result.gatewayUrl}`));
    console.log(pc.dim(`  ├─ Dashboard: ${result.dashboardUrl}`));
    console.log(pc.dim(`  ├─ 配置文件: ${result.configPath}`));
    console.log(pc.dim(`  └─ 日志文件: ${result.logPath}`));
    console.log('');

    if (result.warnings.length > 0) {
      console.log(pc.yellow('  警告:'));
      result.warnings.forEach((w) => {
        console.log(pc.yellow(`  ⚠ ${w.message}`));
      });
      console.log('');
    }

    console.log(pc.cyan('  下一步:'));
    console.log(pc.dim('  1. 打开 Dashboard: ') + pc.underline(result.dashboardUrl || ''));
    console.log(pc.dim('  2. 或运行命令: ') + pc.cyan('openclaw tui'));
    console.log('');
  } else {
    outro(pc.red('✗ 安装失败'));

    console.log('');
    if (result.errors.length > 0) {
      console.log(pc.red('  错误:'));
      result.errors.forEach((e) => {
        console.log(pc.red(`  ✗ [${e.code}] ${e.message}`));
        if (e.suggestion) {
          console.log(pc.dim(`    建议: ${e.suggestion}`));
        }
      });
      console.log('');
    }

    console.log(pc.dim(`  查看详细日志: ${result.logPath || getLogPath()}`));
    console.log('');
  }
}

async function uninstall(options: { yes: boolean }): Promise<void> {
  intro(pc.bgRed(pc.white(' 卸载 OpenClaw ')));

  if (!options.yes) {
    const confirmed = await confirm({
      message: '确定要卸载 OpenClaw 吗？这将删除所有配置和数据。',
      initialValue: false,
    });

    if (isCancel(confirmed) || !confirmed) {
      cancel('卸载已取消');
      return;
    }
  }

  const s = spinner();
  s.start('正在卸载...');

  // Run uninstall commands
  const { executor } = await import('./core/executor.js');

  await executor.run('npm uninstall -g openclaw', { silent: true });

  s.stop('卸载完成');

  outro(pc.green('OpenClaw 已卸载'));
}

async function checkStatus(): Promise<void> {
  intro(pc.bgCyan(pc.black(' OpenClaw 状态 ')));

  const s = spinner();
  s.start('检查安装状态...');

  const env = await detector.detect();

  s.stop('检测完成');

  console.log('');
  console.log(pc.cyan('  环境信息:'));
  console.log(pc.dim(`  ├─ Node.js: ${env.nodejs?.version || '未安装'}`));
  console.log(pc.dim(`  ├─ npm: ${env.npm?.version || '未安装'}`));
  console.log(pc.dim(`  └─ 平台: ${env.platform.os} ${env.platform.arch}`));
  console.log('');

  console.log(pc.cyan('  OpenClaw:'));
  if (env.openclaw?.installed) {
    console.log(pc.green(`  ├─ 已安装: ${env.openclaw.version}`));
    console.log(pc.dim(`  └─ 路径: ${env.openclaw.path}`));
  } else {
    console.log(pc.red('  └─ 未安装'));
  }
  console.log('');

  console.log(pc.cyan('  端口状态:'));
  env.ports.forEach((p) => {
    const status = p.available ? pc.green('可用') : pc.red(`被占用 (${p.process})`);
    console.log(pc.dim(`  ├─ ${p.port}: ${status}`));
  });
  console.log('');

  outro('状态检查完成');
}

program.parse();
