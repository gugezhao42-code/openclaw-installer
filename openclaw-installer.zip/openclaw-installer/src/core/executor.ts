import { execa } from 'execa';
import { logger } from '../utils/logger.js';
import { getShell } from '../utils/platform.js';

export interface ExecuteOptions {
  timeout?: number;
  cwd?: string;
  env?: Record<string, string>;
  silent?: boolean;
  shell?: boolean;
}

export interface ExecuteResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  success: boolean;
}

export class CommandExecutor {
  private defaultTimeout = 300000; // 5 minutes

  async run(
    command: string,
    options: ExecuteOptions = {}
  ): Promise<ExecuteResult> {
    const {
      timeout = this.defaultTimeout,
      cwd,
      env = {},
      silent = false,
      shell = true,
    } = options;

    if (!silent) {
      logger.info(`Executing: ${command}`);
    }

    try {
      const result = await execa(command, {
        shell: shell ? getShell() : false,
        timeout,
        cwd,
        env: { ...process.env, ...env },
        reject: false,
        all: true,
      });

      const success = result.exitCode === 0;

      if (!silent) {
        if (result.stdout) {
          logger.debug(`stdout: ${result.stdout}`);
        }
        if (result.stderr) {
          logger.debug(`stderr: ${result.stderr}`);
        }
      }

      return {
        stdout: result.stdout || '',
        stderr: result.stderr || '',
        exitCode: result.exitCode || 0,
        success,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error(`Command failed: ${errorMessage}`);

      return {
        stdout: '',
        stderr: errorMessage,
        exitCode: 1,
        success: false,
      };
    }
  }

  async runWithRetry(
    command: string,
    options: ExecuteOptions = {},
    maxRetries = 3,
    delayMs = 1000
  ): Promise<ExecuteResult> {
    let lastResult: ExecuteResult | null = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      logger.info(`Attempt ${attempt}/${maxRetries}: ${command}`);

      lastResult = await this.run(command, options);

      if (lastResult.success) {
        return lastResult;
      }

      if (attempt < maxRetries) {
        logger.warn(`Command failed, retrying in ${delayMs}ms...`);
        await this.sleep(delayMs);
        delayMs *= 2; // Exponential backoff
      }
    }

    return lastResult!;
  }

  async runNpm(
    args: string[],
    options: ExecuteOptions = {}
  ): Promise<ExecuteResult> {
    const command = `npm ${args.join(' ')}`;
    return this.run(command, options);
  }

  async runOpenClaw(
    args: string[],
    options: ExecuteOptions = {}
  ): Promise<ExecuteResult> {
    const command = `openclaw ${args.join(' ')}`;
    return this.run(command, options);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

export const executor = new CommandExecutor();
