import { mkdir, writeFile, readFile } from 'fs/promises';
import { existsSync } from 'fs';
import { homedir } from 'os';
import { join } from 'path';
import { logger } from '../utils/logger.js';
import { getOpenClawDir } from '../utils/platform.js';
import { EnvironmentDetector, detector } from './detector.js';
import { CommandExecutor, executor } from './executor.js';
import type {
  InstallOptions,
  InstallResult,
  InstallProgress,
  InstallError,
  InstallWarning,
  InstallStage,
  ModelProvider,
  ProgressCallback,
  EnvironmentInfo,
} from '../types/index.js';

const DEFAULT_PORTS = [18789, 19001, 19002];

export class OpenClawInstaller {
  private options: InstallOptions;
  private progressCallback?: ProgressCallback;
  private detector: EnvironmentDetector;
  private executor: CommandExecutor;
  private errors: InstallError[] = [];
  private warnings: InstallWarning[] = [];
  private selectedPort: number = 19001;

  constructor(options: InstallOptions = { mode: 'interactive' }) {
    this.options = options;
    this.detector = detector;
    this.executor = executor;
  }

  onProgress(callback: ProgressCallback): void {
    this.progressCallback = callback;
  }

  async install(): Promise<InstallResult> {
    logger.info('Starting OpenClaw installation...');
    this.errors = [];
    this.warnings = [];

    try {
      // Stage 1: Environment Detection
      this.updateProgress('detecting', 5, '检测系统环境...');
      const env = await this.detectEnvironment();
      this.validateEnvironment(env);

      // Stage 2: Install OpenClaw
      this.updateProgress('installing-openclaw', 20, '安装 OpenClaw...');
      await this.installOpenClaw();

      // Stage 3: Initialize Configuration
      this.updateProgress('configuring', 60, '初始化配置...');
      await this.initializeConfig();

      // Stage 4: Configure Model (if provided)
      if (this.options.model && this.options.apiKey) {
        this.updateProgress('configuring-model', 70, '配置 AI 模型...');
        await this.configureModel(this.options.model, this.options.apiKey);
      }

      // Stage 5: Start Gateway
      this.updateProgress('starting-gateway', 85, '启动 Gateway 服务...');
      await this.startGateway();

      // Stage 6: Health Check
      this.updateProgress('health-check', 95, '健康检查...');
      const healthy = await this.healthCheck();

      // Stage 7: Complete
      this.updateProgress('completed', 100, '安装完成！');

      return {
        success: true,
        version: await this.getInstalledVersion(),
        gatewayUrl: `ws://127.0.0.1:${this.selectedPort}`,
        dashboardUrl: `http://127.0.0.1:${this.selectedPort}/`,
        configPath: join(getOpenClawDir(), 'openclaw.json'),
        logPath: join(homedir(), '.openclaw-installer', 'logs', 'install.log'),
        errors: this.errors,
        warnings: this.warnings,
      };
    } catch (error) {
      this.updateProgress('failed', 0, '安装失败');
      const installError = this.handleError(error);
      this.errors.push(installError);

      return {
        success: false,
        errors: this.errors,
        warnings: this.warnings,
      };
    }
  }

  private async detectEnvironment(): Promise<EnvironmentInfo> {
    return this.detector.detect();
  }

  private validateEnvironment(env: EnvironmentInfo): void {
    // Check Node.js
    if (!env.nodejs) {
      this.addError(
        'NODEJS_NOT_FOUND',
        'Node.js 未安装',
        'detecting',
        false,
        '请安装 Node.js 22 或更高版本'
      );
      throw new Error('Node.js not found');
    }

    if (!env.nodejs.satisfies('>=22.0.0')) {
      this.addWarning(
        'NODEJS_VERSION_LOW',
        `Node.js 版本过低 (${env.nodejs.version})，建议升级到 22+`,
        'medium'
      );
    }

    // Check npm
    if (!env.npm) {
      this.addError(
        'NPM_NOT_FOUND',
        'npm 未找到',
        'detecting',
        false,
        '请确保 Node.js 正确安装'
      );
      throw new Error('npm not found');
    }

    // Check permissions
    if (!env.permissions.canWriteHome) {
      this.addError(
        'PERMISSION_DENIED',
        '无法写入用户目录',
        'detecting',
        false,
        '请检查文件系统权限'
      );
      throw new Error('Cannot write to home directory');
    }

    if (!env.permissions.canWriteGlobal) {
      this.addWarning(
        'GLOBAL_PERMISSION_DENIED',
        '无法写入全局 npm 目录，可能需要管理员权限',
        'medium'
      );
    }

    // Select available port
    const availablePort = env.ports.find((p) => p.available);
    if (availablePort) {
      this.selectedPort = availablePort.port;
    } else {
      this.selectedPort = 19001;
      this.addWarning(
        'PORT_IN_USE',
        '默认端口被占用，将使用备用端口',
        'low'
      );
    }

    // Check if already installed
    if (env.openclaw?.installed) {
      this.addWarning(
        'ALREADY_INSTALLED',
        `OpenClaw 已安装 (版本: ${env.openclaw.version})，将进行更新`,
        'low'
      );
    }
  }

  private async installOpenClaw(): Promise<void> {
    // Clean npm cache
    this.updateProgress('installing-openclaw', 25, '清理 npm 缓存...');
    await this.executor.run('npm cache clean --force', { silent: true });

    // Install OpenClaw with --ignore-scripts to avoid native module issues
    this.updateProgress('installing-openclaw', 30, '下载 OpenClaw 包...');
    
    const registryFlag = this.options.registry ? `--registry ${this.options.registry}` : '';
    const installCommand = `npm install -g openclaw@latest --ignore-scripts ${registryFlag}`.trim();

    const result = await this.executor.runWithRetry(
      installCommand,
      { timeout: 600000 }, // 10 minutes
      3
    );

    if (!result.success) {
      // Try with different registry
      if (!this.options.registry) {
        this.addWarning(
          'INSTALL_FAILED_DEFAULT_REGISTRY',
          '默认源安装失败，尝试使用镜像源',
          'medium'
        );

        const mirrorResult = await this.executor.runWithRetry(
          'npm install -g openclaw@latest --ignore-scripts --registry https://registry.npmmirror.com',
          { timeout: 600000 },
          2
        );

        if (!mirrorResult.success) {
          throw new Error(`Failed to install OpenClaw: ${mirrorResult.stderr}`);
        }
      } else {
        throw new Error(`Failed to install OpenClaw: ${result.stderr}`);
      }
    }

    this.updateProgress('installing-openclaw', 55, '验证安装...');
    
    const verifyResult = await this.executor.run('openclaw --help', { silent: true });
    if (!verifyResult.success) {
      throw new Error('OpenClaw installation verification failed');
    }
  }

  private async initializeConfig(): Promise<void> {
    const openclawDir = getOpenClawDir();

    // Create directories
    if (!existsSync(openclawDir)) {
      await mkdir(openclawDir, { recursive: true });
    }

    const workspaceDir = join(openclawDir, 'workspace');
    const agentsDir = join(openclawDir, 'agents', 'main', 'sessions');

    if (!existsSync(workspaceDir)) {
      await mkdir(workspaceDir, { recursive: true });
    }
    if (!existsSync(agentsDir)) {
      await mkdir(agentsDir, { recursive: true });
    }

    // Run openclaw setup
    const setupResult = await this.executor.run('openclaw setup', { silent: true });
    if (!setupResult.success) {
      // Create config manually if setup fails
      await this.createDefaultConfig();
    }

    // Set gateway mode and port
    await this.executor.run(`openclaw config set gateway.mode local`, { silent: true });
    await this.executor.run(`openclaw config set gateway.port ${this.selectedPort}`, { silent: true });
  }

  private async createDefaultConfig(): Promise<void> {
    const configPath = join(getOpenClawDir(), 'openclaw.json');
    const config = {
      meta: {
        lastTouchedVersion: '2026.2.26',
        lastTouchedAt: new Date().toISOString(),
      },
      agents: {
        defaults: {
          workspace: join(getOpenClawDir(), 'workspace'),
        },
      },
      gateway: {
        mode: 'local',
        port: this.selectedPort,
        auth: {
          token: 'auto',
        },
      },
    };

    await writeFile(configPath, JSON.stringify(config, null, 2));
  }

  private async configureModel(model: ModelProvider, apiKey: string): Promise<void> {
    const modelMap: Record<string, string> = {
      kimi: 'moonshot/kimi-k2.5',
      openai: 'openai/gpt-4o',
      anthropic: 'anthropic/claude-opus-4-6',
      ollama: 'ollama/llama3',
    };

    const defaultModel = modelMap[model.name] || model.model;

    // Use openclaw config command
    if (model.name === 'kimi') {
      // Configure Kimi API
      await this.executor.run(
        `openclaw models auth paste-token --provider moonshot --profile-id moonshot:default`,
        { silent: true }
      );
      
      // Set API key in auth profiles
      const authPath = join(getOpenClawDir(), 'agents', 'main', 'agent', 'auth-profiles.json');
      const authConfig = {
        profiles: {
          'moonshot:default': {
            id: 'moonshot:default',
            provider: 'moonshot',
            apiKey: apiKey,
            createdAt: new Date().toISOString(),
          },
        },
        order: ['moonshot:default'],
      };

      const agentDir = join(getOpenClawDir(), 'agents', 'main', 'agent');
      if (!existsSync(agentDir)) {
        await mkdir(agentDir, { recursive: true });
      }
      await writeFile(authPath, JSON.stringify(authConfig, null, 2));
    }

    // Set default model
    await this.executor.run(`openclaw models set ${defaultModel}`, { silent: true });
  }

  private async startGateway(): Promise<void> {
    // Gateway will be started in background
    // For now, we just verify it can start
    const result = await this.executor.run(
      `openclaw gateway run --port ${this.selectedPort}`,
      {
        timeout: 10000,
        silent: true,
      }
    );

    // Gateway runs in foreground, so we expect it to not exit immediately
    // If it exits quickly, there's an error
    if (result.exitCode !== 0 && !result.stdout.includes('listening')) {
      this.addWarning(
        'GATEWAY_START_WARNING',
        `Gateway 启动可能有问题: ${result.stderr}`,
        'medium'
      );
    }
  }

  private async healthCheck(): Promise<boolean> {
    // Wait a moment for gateway to start
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = await this.executor.run('openclaw health', {
      timeout: 15000,
      silent: true,
    });

    return result.success;
  }

  private async getInstalledVersion(): Promise<string> {
    const result = await this.executor.run('openclaw --version', { silent: true });
    const match = result.stdout.match(/(\d+\.\d+\.\d+)/);
    return match ? match[1] : 'unknown';
  }

  private updateProgress(
    stage: InstallStage,
    progress: number,
    message: string,
    details?: Record<string, unknown>
  ): void {
    logger.info(`[${stage}] ${progress}% - ${message}`);

    if (this.progressCallback) {
      this.progressCallback({ stage, progress, message, details });
    }
  }

  private addError(
    code: string,
    message: string,
    stage: InstallStage,
    recoverable: boolean,
    suggestion?: string
  ): void {
    this.errors.push({ code, message, stage, recoverable, suggestion });
    logger.error(`[${code}] ${message}`);
  }

  private addWarning(code: string, message: string, impact: 'low' | 'medium' | 'high'): void {
    this.warnings.push({ code, message, impact });
    logger.warn(`[${code}] ${message}`);
  }

  private handleError(error: unknown): InstallError {
    if (error instanceof Error) {
      return {
        code: 'UNKNOWN_ERROR',
        message: error.message,
        stage: 'failed',
        recoverable: false,
        suggestion: '请查看日志文件获取详细信息',
      };
    }

    return {
      code: 'UNKNOWN_ERROR',
      message: String(error),
      stage: 'failed',
      recoverable: false,
    };
  }
}
