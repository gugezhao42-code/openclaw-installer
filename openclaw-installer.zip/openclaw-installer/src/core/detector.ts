import { exec } from 'child_process';
import { promisify } from 'util';
import { createConnection } from 'net';
import semver from 'semver';
import { access, constants } from 'fs/promises';
import { homedir } from 'os';
import { join } from 'path';
import { logger } from '../utils/logger.js';
import { getPlatform, getHomeDir } from '../utils/platform.js';
import type {
  EnvironmentInfo,
  NodeJSInfo,
  NpmInfo,
  PermissionInfo,
  PortInfo,
  OpenClawInfo,
} from '../types/index.js';

const execAsync = promisify(exec);

export class EnvironmentDetector {
  async detect(): Promise<EnvironmentInfo> {
    logger.info('Starting environment detection...');

    const [nodejs, npm, permissions, ports, openclaw] = await Promise.all([
      this.detectNodeJS(),
      this.detectNpm(),
      this.checkPermissions(),
      this.checkPorts([18789, 19001, 19002, 19003]),
      this.detectOpenClaw(),
    ]);

    const info: EnvironmentInfo = {
      nodejs,
      npm,
      permissions,
      ports,
      platform: getPlatform(),
      openclaw,
    };

    logger.info(`Environment detection completed: ${JSON.stringify({
      nodejs: nodejs?.version,
      npm: npm?.version,
      openclaw: openclaw?.installed,
    })}`);

    return info;
  }

  async detectNodeJS(): Promise<NodeJSInfo | null> {
    try {
      const { stdout: versionOutput } = await execAsync('node -v');
      const version = versionOutput.trim().replace(/^v/, '');

      const { stdout: pathOutput } = await execAsync(
        process.platform === 'win32' ? 'where node' : 'which node'
      );
      const path = pathOutput.trim().split('\n')[0];

      return {
        version,
        path,
        satisfies: (range: string) => semver.satisfies(version, range),
      };
    } catch (error) {
      logger.warn('Node.js not found');
      return null;
    }
  }

  async detectNpm(): Promise<NpmInfo | null> {
    try {
      const { stdout: versionOutput } = await execAsync('npm -v');
      const version = versionOutput.trim();

      const { stdout: pathOutput } = await execAsync(
        process.platform === 'win32' ? 'where npm' : 'which npm'
      );
      const path = pathOutput.trim().split('\n')[0];

      let registry = 'https://registry.npmjs.org';
      try {
        const { stdout: registryOutput } = await execAsync('npm config get registry');
        registry = registryOutput.trim();
      } catch {
        // Use default registry
      }

      return { version, path, registry };
    } catch (error) {
      logger.warn('npm not found');
      return null;
    }
  }

  async checkPermissions(): Promise<PermissionInfo> {
    const result: PermissionInfo = {
      admin: false,
      canWriteGlobal: false,
      canWriteHome: false,
    };

    // Check home directory write permission
    try {
      await access(homedir(), constants.W_OK);
      result.canWriteHome = true;
    } catch {
      logger.warn('Cannot write to home directory');
    }

    // Check global npm directory write permission
    try {
      const { stdout: prefixPath } = await execAsync('npm config get prefix');
      const prefix = prefixPath.trim();
      await access(prefix, constants.W_OK);
      result.canWriteGlobal = true;
    } catch {
      logger.warn('Cannot write to global npm directory');
    }

    // Check admin/root privileges
    if (process.platform === 'win32') {
      try {
        await execAsync('net session');
        result.admin = true;
      } catch {
        // Not admin
      }
    } else {
      result.admin = process.getuid?.() === 0;
    }

    return result;
  }

  async checkPorts(ports: number[]): Promise<PortInfo[]> {
    const results: PortInfo[] = [];

    for (const port of ports) {
      const available = await this.isPortAvailable(port);
      results.push({
        port,
        available,
        process: available ? undefined : await this.getPortProcess(port),
      });
    }

    return results;
  }

  private isPortAvailable(port: number): Promise<boolean> {
    return new Promise((resolve) => {
      const server = createConnection(port, '127.0.0.1', () => {
        server.end();
        resolve(false);
      });
      server.on('error', () => resolve(true));
      server.setTimeout(1000, () => {
        server.destroy();
        resolve(true);
      });
    });
  }

  private async getPortProcess(port: number): Promise<string | undefined> {
    try {
      if (process.platform === 'win32') {
        const { stdout } = await execAsync(`netstat -ano | findstr :${port}`);
        const match = stdout.match(/(\d+)\s*$/m);
        if (match) {
          const pid = match[1];
          try {
            const { stdout: processInfo } = await execAsync(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`);
            const nameMatch = processInfo.match(/"([^"]+)"/);
            return nameMatch ? `${nameMatch[1]} (PID: ${pid})` : `PID: ${pid}`;
          } catch {
            return `PID: ${pid}`;
          }
        }
      } else {
        const { stdout } = await execAsync(`lsof -i :${port} -t`);
        const pid = stdout.trim().split('\n')[0];
        if (pid) {
          const { stdout: processName } = await execAsync(`ps -p ${pid} -o comm=`);
          return `${processName.trim()} (PID: ${pid})`;
        }
      }
    } catch {
      // Port info not available
    }
    return undefined;
  }

  async detectOpenClaw(): Promise<OpenClawInfo> {
    try {
      const { stdout: versionOutput } = await execAsync('openclaw --version');
      const versionMatch = versionOutput.match(/(\d+\.\d+\.\d+)/);
      const version = versionMatch ? versionMatch[1] : undefined;

      const { stdout: pathOutput } = await execAsync(
        process.platform === 'win32' ? 'where openclaw' : 'which openclaw'
      );
      const path = pathOutput.trim().split('\n')[0];

      return {
        installed: true,
        version,
        path,
      };
    } catch {
      return { installed: false };
    }
  }

  getAvailablePort(preferredPorts: number[]): number {
    const env = process.env.OPENCLAW_PORT;
    if (env) {
      return parseInt(env, 10);
    }
    return preferredPorts[0];
  }
}

export const detector = new EnvironmentDetector();
