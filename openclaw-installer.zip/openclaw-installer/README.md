# 🦞 OpenClaw Installer

一键安装器 for [OpenClaw](https://github.com/claw-ai/openclaw) - AI 助手自动化平台

## 功能特性

- ✅ **一键安装** - 自动检测环境并安装 OpenClaw
- 🔧 **智能配置** - 自动配置 Gateway、AI 模型
- 🌐 **多模型支持** - 支持 Kimi、OpenAI、Claude、Ollama 等
- 📊 **进度显示** - 实时显示安装进度
- 🔍 **环境检测** - 自动检测 Node.js、npm、端口等
- 🛠️ **错误恢复** - 自动重试和错误恢复机制
- 🖥️ **交互式/静默模式** - 支持图形向导和命令行模式

## 安装要求

- Node.js >= 22.0.0
- npm >= 10.0.0
- 管理员权限（Windows）或 sudo（Linux/macOS）

## 快速开始

### 交互式安装

```bash
npx openclaw-install
```

### 快速安装（使用默认配置）

```bash
npx openclaw-install --quick --model kimi --api-key YOUR_API_KEY
```

### 静默安装

```bash
npx openclaw-install --silent --model kimi --api-key YOUR_API_KEY --port 19001
```

## 命令选项

```bash
Options:
  -V, --version          显示版本号
  -s, --silent           静默模式（非交互式）
  -q, --quick            快速安装（使用默认配置）
  -r, --repair           修复现有安装
  -c, --config <path>    配置文件路径
  --model <provider>     AI 模型提供商 (kimi|openai|anthropic|ollama)
  --api-key <key>        模型提供商的 API Key
  --port <port>          Gateway 端口
  --registry <url>       npm 镜像源
  -v, --verbose          详细输出
  -h, --help             显示帮助信息

Commands:
  uninstall [options]    卸载 OpenClaw
  status                 检查安装状态
```

## 支持的 AI 模型

| 提供商 | 模型 | 说明 |
|--------|------|------|
| Kimi | moonshot/kimi-k2.5 | 月之暗面，国内推荐 |
| OpenAI | openai/gpt-4o | GPT-4 系列 |
| Anthropic | anthropic/claude-opus-4-6 | Claude 系列 |
| Ollama | ollama/llama3 | 本地模型 |

## 安装流程

```
1. 环境检测
   ├─ Node.js 版本检查
   ├─ npm 可用性检查
   ├─ 权限检查
   └─ 端口可用性检查

2. 安装 OpenClaw
   ├─ 清理 npm 缓存
   ├─ 下载并安装 openclaw
   └─ 验证安装

3. 配置初始化
   ├─ 创建配置目录
   ├─ 生成默认配置
   └─ 设置 Gateway 参数

4. 模型配置（可选）
   ├─ 配置 API Key
   ├─ 设置默认模型
   └─ 验证模型连接

5. 服务启动
   ├─ 启动 Gateway
   ├─ 健康检查
   └─ 显示访问信息
```

## 项目结构

```
openclaw-installer/
├── src/
│   ├── core/              # 核心模块
│   │   ├── detector.ts    # 环境检测器
│   │   ├── executor.ts    # 命令执行器
│   │   └── installer.ts   # 安装控制器
│   ├── modules/           # 功能模块
│   │   ├── environment/   # 环境管理
│   │   ├── config/        # 配置管理
│   │   └── service/       # 服务管理
│   ├── ui/                # 用户界面
│   │   └── cli/           # CLI 界面
│   ├── utils/             # 工具函数
│   │   ├── logger.ts      # 日志系统
│   │   └── platform.ts    # 平台检测
│   └── types/             # 类型定义
│       └── index.ts
├── resources/             # 资源文件
│   └── config-templates/  # 配置模板
├── package.json
├── tsconfig.json
└── README.md
```

## 开发

### 安装依赖

```bash
cd openclaw-installer
npm install
```

### 开发模式

```bash
npm run dev
```

### 构建

```bash
npm run build
```

### 测试

```bash
npm test
```

## 常见问题

### Q: 安装失败，提示权限不足？

**A:** 在 Windows 上以管理员身份运行 PowerShell，在 Linux/macOS 上使用 `sudo`：

```bash
# Windows (管理员 PowerShell)
npx openclaw-install

# Linux/macOS
sudo npx openclaw-install
```

### Q: 端口被占用怎么办？

**A:** 安装器会自动检测并选择可用端口，也可以手动指定：

```bash
npx openclaw-install --port 19002
```

### Q: 如何更换 npm 镜像源？

**A:** 使用 `--registry` 参数：

```bash
npx openclaw-install --registry https://registry.npmmirror.com
```

### Q: 安装后如何配置其他模型？

**A:** 可以通过 Dashboard 配置：

```bash
openclaw dashboard
```

或者使用命令行：

```bash
openclaw config --section models
```

## 日志文件

安装日志保存在：

- Windows: `%USERPROFILE%\.openclaw-installer\logs\install.log`
- Linux/macOS: `~/.openclaw-installer/logs/install.log`

## 许可证

MIT

## 相关链接

- [OpenClaw 官方文档](https://docs.openclaw.ai)
- [OpenClaw GitHub](https://github.com/claw-ai/openclaw)
- [Kimi API 文档](https://platform.moonshot.cn/docs)
